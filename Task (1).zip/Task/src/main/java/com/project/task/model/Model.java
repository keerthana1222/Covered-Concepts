package com.project.task.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "EUCTaskk")
public class Model {
	@Id
	  @Column(name = "Country")
	  private String Country;
//	  @Column(name = "Capital")
//	  private String Capital;
	  @Column(name = "Population")
	  private Long Population;
	public Model() {
		super();
		this.Country = Country;
		//this.Capital = Capital;
		this.Population = Population;
	}
	@Override
	public String toString() {
		return "Model [Country=" + Country + ", Population=" + Population + "]";
	}
	public String getCountry() {
		return Country;
	}
	public void setCountry(String country) {
		Country = country;
	}
//	public String getCapital() {
//		return Capital;
//	}
//	public void setCapital(String capital) {
//		Capital = capital;
	//}
	public Long getPopulation() {
		return Population;
	}
	public void setPopulation(Long population) {
		Population = population;
	}
	  
	  
}
