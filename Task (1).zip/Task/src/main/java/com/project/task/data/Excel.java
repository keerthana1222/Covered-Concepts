package com.project.task.data;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.web.multipart.MultipartFile;

import com.project.task.model.Model;


public class Excel {
	  public static String TYPE = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
	  static String[] HEADERs = { "Country", "Population"};
	  static String SHEET = "Everything";
	  public static boolean hasExcelFormat(MultipartFile file) throws Exception {
	    if (!TYPE.equals(file.getContentType())) {
	      return false;
	    }
	    return true;
	  }
	  public static List<Model> excelToBooks(InputStream is) {
		    try {
		      Workbook workbook = new XSSFWorkbook(is);
		      Sheet sheet = (Sheet) workbook.getSheet(SHEET);
		      String Name=sheet.getSheetName();
			    System.out.println("sheetname "+ Name);
		    //
			
	      int count=sheet.getLastRowNum()+1;
	      System.out.println(count);
	      Iterator<Row> rows = sheet.iterator();
	      List<Model> lists = new ArrayList<Model>();
	      int rowNumber = 0;
	      
	      while (rows.hasNext()) {
	        Row currentRow = rows.next();
	        // skip header
	        if (rowNumber == 0) {
	          rowNumber++;
	          continue;
	        }
	        Iterator<Cell> cellsInRow = currentRow.iterator();
	        Model m = new Model();
	        int cell = 0;
	        while (cellsInRow.hasNext()) {
	          Cell currentCell = cellsInRow.next();
	          switch (cell) {
	          case 0:
	            m.setCountry( currentCell.getStringCellValue());
	            break;
//	          case 1:
//	            m.setCapital(currentCell.getStringCellValue());
//	            break;
	          case 1:
	            m.setPopulation((long)currentCell.getNumericCellValue());
	            break;
	          default:
	            break;
	          }
	          	  	
	          cell++;
	         
	        }
	        lists.add(m);
	      }
	      workbook.close();
	      return lists;
	    } catch (IOException e) {
	      throw new RuntimeException("fail to parse Excel file: " + e.getMessage());
	    }
	  }

}
