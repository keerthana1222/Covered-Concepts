package com.project.task.ser;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;


import com.project.task.data.Excel;
import com.project.task.repo.BookRepo;

@Service
public class XIServices {
	@Autowired
	  BookRepo repo;
	  public void save(MultipartFile file) {
	    try {
	      List<com.project.task.model.Model> lists = Excel.excelToBooks(file.getInputStream());
	      repo.saveAll(lists);
	    } catch (IOException e) {
	      throw new RuntimeException("fail to store excel data: " + e.getMessage());
	    }
	  }
	  public List<com.project.task.model.Model> getAllBooks() {
	    return repo.findAll();
	  }
}
