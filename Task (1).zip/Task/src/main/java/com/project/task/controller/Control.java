package com.project.task.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

 
import com.project.task.data.Excel;
import com.project.task.message.Message;
import com.project.task.model.Model;
import com.project.task.ser.XIServices;

@CrossOrigin(origins="http://localhost:3000")
@RestController
@RequestMapping("/api/excel")
public class Control {@Autowired
	  XIServices fileService;
	  @PostMapping("/upload")
	  public ResponseEntity<Message> uploadFile(@RequestParam("file") MultipartFile file) throws Exception {
	    String message = "";
	    if (Excel.hasExcelFormat(file)) {
	      try {
	    	  fileService.save(file);
	        message = "Uploaded the file successfully: " + file.getOriginalFilename();
	        return ResponseEntity.status(HttpStatus.OK).body(new Message(message));
	      } catch (Exception e) {
	        message = "Could not upload the file: " + file.getOriginalFilename() + "!";
	        return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body(new Message(message));
	      }
	    }
	    message = "Please upload an excel file!";
	    return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new Message(message));
	  }
	  @GetMapping("/EUCTaskkPivot")
	  public ResponseEntity<List<Model>> getAllBooks() {
	    try {
	      List<Model> lists = fileService.getAllBooks();
	      if (lists.isEmpty()) {
	        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	      }
	      return new ResponseEntity<>(lists, HttpStatus.OK);
	    } catch (Exception e) {
	      return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	  }

}
