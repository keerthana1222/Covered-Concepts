package com.project.task.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.task.model.Model;



public interface BookRepo extends JpaRepository<Model, Long>{

}
