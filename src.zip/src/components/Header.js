import React from 'react'

export const Header = () => {
  return (
    <div>
      <h2>Header</h2>
    </div>
  )
}

 
