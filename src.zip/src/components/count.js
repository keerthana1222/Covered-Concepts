import React, { useState } from 'react'

const count =() =>{
//  const [name,setName]=useState("skillhub")
const[count,setCount] = useState(0);
    return (
      <div>
        <center>
        {/* <h1>{name}</h1> */}
        {/* <button onClick={() => setName("Telugu Skill Hub")}>Change</button> */}
<h1>{count}</h1>
<button onClick={() => setCount(count+1)}>Change</button>
        </center>
      </div>
    )
  
}
export default count;
