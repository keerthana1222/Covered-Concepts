import React from 'react'
import {Header} from './components/Header'; //in header i used export
import Home from './components/Home'; //in Home i used default export
import Footer from './components/Footer';
function exportt() {
  return (
    <div>
      <Header></Header>
      <Home></Home>
      <Footer></Footer>
    </div>
  );
}
export default exportt