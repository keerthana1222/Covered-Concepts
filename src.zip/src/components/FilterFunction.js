import React from 'react'

 function FilterFunction() {
  // const names=["keethu","abhi","pav","harish","sweth"];
  //const filtered = names.filter(name =>name.includes('a'))
  const arr=[10,20,30,40,50,60,70,80,90]
  const filtered = arr.filter(item =>item>40)
  return (
    <div>
      {
        filtered.map(item => <li>{item}</li>)
      }
    </div>
  );
}
export default FilterFunction
