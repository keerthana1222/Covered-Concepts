import React ,{useState,useEffect} from 'react'

function useEffect() {
  const[count,setCount] = useState(0);
  useEffect(() =>console.log(count),[count]) // after return statement useffect will execute only one time because there is no dependencies
  return (
    <div>
      <center>
      <p>You clicked  {count} times</p>
      <button onClick={() => setCount(count+1)}>Click ME</button>
      </center>
    </div>
  )
}

export default useEffect