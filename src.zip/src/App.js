// import React from 'react'

// const App = () =>{

//     return (
//       <div>
//         <button onClick={()=>console.log("clicked")}>Click Here</button>
//       </div>
//     )
  
// }
// export default App;














// import React from 'react'
// import Login from './components/Login'

// function App() {
//   return (
//     <div>
//       //<Login></Login>
      
//     </div>
//   )
// }

// export default App

import React from 'react'
import SignUpForm from './components/SignUpForm'

 function App() {
  return (
    <div>
     <SignUpForm></SignUpForm> 
    </div>
  )
}
export default App