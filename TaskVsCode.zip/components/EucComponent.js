import React, { Component } from "react";
import NewService from "../services/EucService";

class EucComponent extends Component{
    constructor(props) {
        super(props);
        this.state = {
           EUC : [],
        };
    }   
    
componentDidMount() {
NewService.getNewData().then((response) => {
      this.setState({EUC:response.data,
      });    
      console.log(response.data);

    })
      .catch(() => {
        this.setState({
          errorMessage: "err",
        });
       
      });
    }
    
      render() {
        return (
          <div>
            <center>
          <h1>RECORDS</h1>
          <table>
          <thead>
            <tr>
             <td>country</td>
              <td>population</td>
            </tr>
          </thead>
          <tbody>
            {
              this.state.EUC.map((t,a)=> {
                return(
                  
                  <tr key={a}>
                    <td>{t.country}</td>
                    <td>{t.population}</td>
                  </tr>
                  
                )
              })}
          </tbody>
          </table>
          </center>
         </div>
        )
     }
  }
export default EucComponent;